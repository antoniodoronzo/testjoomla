/**
 * Appened default Comment JS for HD Video Share
 *
 * This file is to append default comment in player page
 *
 * @category   Apptha
 * @package    Com_Contushdvideoshare
 * @version    3.8
 * @author     Apptha Team <developers@contus.in>
 * @copyright  Copyright (C) 2015 Apptha. All rights reserved.
 * @license    GNU General Public License http://www.gnu.org/copyleft/gpl.html
 */

function parentvalue(e) {
    document.getElementById("parentvalue").value = e;
    document.getElementById("name").focus();
}

<?php 
/**
 * Subscriber for HD Video Share
 *
 * This file is to display popup player
 *
 * @category   Apptha
 * @package    Com_Contushdvideoshare
 * @version    3.8
 * @author     Apptha Team <developers@contus.in>
 * @copyright  Copyright (C) 2015 Apptha. All rights reserved.
 * @license    GNU General Public License http://www.gnu.org/copyleft/gpl.html
 */

include_once(JPATH_ROOT.'/components/com_contushdvideoshare/views/channel/tmpl/subscriper.php');
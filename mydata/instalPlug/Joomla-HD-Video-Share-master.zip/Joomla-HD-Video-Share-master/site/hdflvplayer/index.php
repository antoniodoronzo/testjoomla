<html>
    <head><title>No Direct Access</title></head>
    <body></body>
</html>
# Joomla-HD-Video-Share
HD Video Share is the trendsetter for online video sharing. Has the most number of features and allows you to take control of your domain/site at ease. Start your own video sharing site packed with the most powerful features in just minutes.
